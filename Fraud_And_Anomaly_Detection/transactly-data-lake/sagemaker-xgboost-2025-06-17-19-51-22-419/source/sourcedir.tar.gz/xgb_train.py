import argparse
import pandas as pd
import xgboost as xgb
import joblib
import os
from sklearn.metrics import average_precision_score

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=str)
    parser.add_argument("--model-dir", type=str)
    args = parser.parse_args()
    
    # Load data
    train = pd.read_parquet(f"{args.data_dir}/train.parquet")
    val = pd.read_parquet(f"{args.data_dir}/val.parquet")
    
    # Separate features and labels
    X_train = train.drop('fraud_label', axis=1) if 'fraud_label' in train.columns else train
    y_train = train['fraud_label'] if 'fraud_label' in train.columns else None
    
    X_val = val.drop('fraud_label', axis=1) if 'fraud_label' in val.columns else val
    y_val = val['fraud_label'] if 'fraud_label' in val.columns else None
    
    # Train model
    model = xgb.XGBClassifier(
        objective='binary:logistic',
        eval_metric='aucpr',
        scale_pos_weight=30,
        max_depth=5,
        subsample=0.8,
        n_estimators=300
    )
    model.fit(X_train, y_train)
    
    # Evaluate
    val_pred = model.predict_proba(X_val)[:,1]
    aucpr = average_precision_score(y_val, val_pred)
    print(f"Validation AUCPR: {aucpr:.4f}")
    
    # Save model
    os.makedirs(args.model_dir, exist_ok=True)
    joblib.dump(model, f"{args.model_dir}/xgb_model.joblib")
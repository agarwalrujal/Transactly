import pandas as pd
import xgboost as xgb
import os
import argparse
from sklearn.metrics import average_precision_score

def load_data_from_path(base_path):
    """Load training and validation data from specified directory"""
    files = {
        'train': 'train.csv',
        'train_labels': 'train_labels.csv',
        'val': 'val.csv',
        'val_labels': 'val_labels.csv'
    }

    data = {}
    for name, filename in files.items():
        path = os.path.join(base_path, filename)
        if not os.path.exists(path):
            raise FileNotFoundError(f"Missing required file: {path}")
        print(f"Loading {name} from {path}")
        data[name] = pd.read_csv(path)
        if 'label' in name:
            data[name] = data[name].squeeze()  # Convert single-column DataFrame to Series
    return data

def preprocess_dataframe(df):
    """Convert categorical/object columns to numeric codes"""
    for col in df.columns:
        if df[col].dtype == 'object':
            try:
                df[col] = pd.to_numeric(df[col])
            except ValueError:
                df[col] = df[col].astype('category').cat.codes
    return df

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--train", type=str, default=os.environ.get("SM_CHANNEL_TRAIN"), help="Input training directory")
    parser.add_argument("--model-dir", type=str, default=os.environ.get("SM_MODEL_DIR"), help="Output model directory")
    parser.add_argument("--objective", type=str)
    parser.add_argument("--eval_metric", type=str)
    parser.add_argument("--scale_pos_weight", type=float)
    parser.add_argument("--max_depth", type=int)
    parser.add_argument("--subsample", type=float)
    parser.add_argument("--num_round", type=int)
    args = parser.parse_args()

    print(f"Loading training data from: {args.train}")
    data = load_data_from_path(args.train)

    # Preprocess features
    data['train'] = preprocess_dataframe(data['train'])
    data['val'] = preprocess_dataframe(data['val'])

    # Create XGBoost DMatrices
    dtrain = xgb.DMatrix(data=data['train'], label=data['train_labels'])
    dval = xgb.DMatrix(data=data['val'], label=data['val_labels'])

    # Train model
    print("Starting XGBoost training...")
    model = xgb.train(
        params={
            "objective": args.objective,
            "eval_metric": args.eval_metric,
            "scale_pos_weight": args.scale_pos_weight,
            "max_depth": args.max_depth,
            "subsample": args.subsample
        },
        dtrain=dtrain,
        num_boost_round=args.num_round,
        evals=[(dval, "validation")],
        early_stopping_rounds=10,
        verbose_eval=True
    )

    # Evaluate on validation set
    print("Evaluating model...")
    val_preds = model.predict(dval)
    aucpr = average_precision_score(data['val_labels'], val_preds)
    print(f"Validation AUCPR: {aucpr:.4f}")

    # Save model
    os.makedirs(args.model_dir, exist_ok=True)
    model_path = os.path.join(args.model_dir, "xgboost-model.bst")
    model.save_model(model_path)
    print(f"Model saved to: {model_path}")

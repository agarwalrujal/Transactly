import argparse
import pandas as pd
import numpy as np
import tensorflow as tf
import joblib
import os
from tensorflow.keras.layers import Input, Dense, Concatenate
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping

# ---- Feature Lists ---- #
USER_EMBEDDINGS = [  # keep unchanged
    'recency_days_since_last_txn', 'recency_days_since_last_login', 
    'recency_days_since_last_cart_abandonment', 'recency_days_since_last_support_contact',
    'recency_days_since_last_refund', 'frequency_txns_per_week', 
    'frequency_sessions_per_day', 'frequency_logins_per_month',
    'frequency_failed_logins_per_month', 'frequency_searches_per_session',
    'monetary_avg_order_value_30d', 'monetary_avg_order_value_90d',
    'monetary_total_spend_30d', 'monetary_total_spend_90d',
    'monetary_spend_volatility', 'monetary_median_order_value',
    'monetary_high_ticket_orders', 'monetary_micro_txns',
    'monetary_coupon_usage_rate', 'monetary_gift_card_redemption_rate',
    'cat_electronics', 'cat_grocery', 'cat_fashion', 'cat_home_kitchen',
    'cat_books_media', 'cat_health_beauty', 'cat_sports_outdoors',
    'cat_toys_games', 'cat_automotive', 'cat_prime_video', 'cat_prime_music',
    'cat_kindle', 'cat_aws_api', 'cat_aws_storage', 'cat_amazon_fresh',
    'cat_audible', 'cat_pharmacy', 'cat_amazon_pay', 'cat_amazon_photos',
    'temp_hour_00', 'temp_hour_01', 'temp_hour_02',
    'temp_hour_03', 'temp_hour_04', 'temp_hour_05', 'temp_hour_06',
    'temp_hour_07', 'temp_hour_08', 'temp_hour_09', 'temp_hour_10',
    'temp_hour_11', 'temp_hour_12', 'temp_hour_13', 'temp_hour_14',
    'temp_hour_15', 'temp_hour_16', 'temp_hour_17', 'temp_hour_18',
    'temp_hour_19', 'temp_hour_20', 'temp_hour_21', 'temp_hour_22',
    'temp_hour_23', 'temp_day_mon', 'temp_day_tue', 'temp_day_wed',
    'temp_day_thu', 'temp_day_fri', 'temp_day_sat', 'temp_day_sun',
    'device_pct_mobile', 'device_pct_desktop', 'device_pct_tablet',
    'device_distinct_count', 'device_entropy', 'device_pct_android',
    'device_pct_ios', 'device_pct_windows', 'device_pct_macos',
    'device_pct_headless', 'network_pct_vpn', 'network_avg_asn_score',
    'network_pct_tor', 'network_geo_mismatch', 'network_distinct_ips',
    'network_pct_new_ips', 'geo_city_count', 'geo_country_count',
    'geo_avg_distance', 'geo_max_distance_24h', 'geo_home_mismatch',
    'geo_pct_top_cities', 'geo_pct_overseas', 'geo_cross_region_hops',
    'returns_pct_returned', 'returns_avg_return_time',
    'returns_pct_refunds_approved', 'returns_chargebacks',
    'returns_pct_partial_refunds', 'support_tickets',
    'support_resolution_time', 'support_pct_escalated',
    'support_negative_feedback', 'support_pct_reopened',
    'engagement_avg_pages', 'engagement_ctr', 'engagement_pct_video',
    'engagement_pct_audio', 'engagement_pct_search',
    'engagement_search_abandon', 'engagement_wishlist_adds',
    'engagement_cart_adds', 'engagement_pct_buy_again',
    'engagement_pct_social_share', 'behavior_std_amount',
    'behavior_std_time', 'behavior_std_sessions', 'behavior_gini_spend',
    'behavior_temporal_churn', 'behavior_burstiness',
    'behavior_device_stability', 'behavior_address_stability'
]

REAL_TIME_FEATURES = [
    'amount', 'ip_risk_score', 'country_code', 'device_age_days',
    'hour_of_day', 'is_vpn', 'distance_from_home_km', 'category_id',
    'cvv_attempts', 'session_duration_sec', 'is_new_device',
    'payment_method', 'shipping_billing_match'
]

# ---- Model Definition ---- #
def create_model(user_embedding_dim, real_time_dim):
    user_input = Input(shape=(user_embedding_dim,), name='user_embedding')
    rt_input = Input(shape=(real_time_dim,), name='real_time_features')
    baseline_input = Input(shape=(1,), name='baseline_score')

    wide = Dense(64, activation='relu')(rt_input)

    deep = Concatenate()([user_input, baseline_input])
    deep = Dense(256, activation='relu')(deep)
    deep = Dense(128, activation='relu')(deep)

    combined = Concatenate()([wide, deep])
    output = Dense(1, activation='sigmoid')(combined)

    return Model(inputs=[user_input, rt_input, baseline_input], outputs=output)

# ---- Main Script ---- #
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    
    parser.add_argument("--train", type=str, default=os.environ.get("SM_CHANNEL_TRAIN", "/opt/ml/input/data/train"))
    parser.add_argument("--xgb_model", type=str, default=os.environ.get("SM_CHANNEL_XGB_MODEL", "/opt/ml/input/data/xgb_model"))
    parser.add_argument("--preprocessor", type=str, default=os.environ.get("SM_CHANNEL_PREPROCESSOR", "/opt/ml/input/data/preprocessor"))
    parser.add_argument("--model_dir", type=str, default=os.environ.get("SM_MODEL_DIR", "/opt/ml/model"))

    args = parser.parse_args()
    
    print(f"Training data path: {args.train}")
    print(f"XGBoost model path: {args.xgb_model}")
    print(f"Preprocessor path: {args.preprocessor}")

    # ---- Load data ---- #
    train_csv_path = os.path.join(args.train, "train.csv")
    if not os.path.exists(train_csv_path):
        raise FileNotFoundError(f"Training file not found at {train_csv_path}")
    
    train_data = pd.read_csv(train_csv_path)
    print(f"Loaded training data with shape: {train_data.shape}")
    
    if "fraud_label" not in train_data.columns:
        raise ValueError("Column 'fraud_label' not found in training data")

    # ---- Load preprocessor ---- #
    preprocessor_path = os.path.join(args.preprocessor, "preprocessor.joblib")
    if not os.path.exists(preprocessor_path):
        raise FileNotFoundError(f"Preprocessor not found at {preprocessor_path}")
    
    preprocessor = joblib.load(preprocessor_path)

    # ---- Load XGBoost model ---- #
    import tarfile

    tar_path = "/opt/ml/input/data/xgb_model/model.tar.gz"
    extract_path = "/opt/ml/input/data/xgb_model"

    with tarfile.open(tar_path) as tar:
        tar.extractall(path=extract_path)

    #xgb_model_path = os.path.join(extract_path, "model.joblib")
    xgb_model_path = os.path.join(args.xgb_model, "model.joblib")
    if not os.path.exists(xgb_model_path):
        raise FileNotFoundError(f"XGBoost model not found at {xgb_model_path}")
    
    xgb_model = joblib.load(xgb_model_path)

    # ---- Transform real-time features ---- #
    print("Transforming real-time features...")
    X_rt = preprocessor.transform(train_data[REAL_TIME_FEATURES])
    real_time_dim = X_rt.shape[1]

    # ---- Generate baseline score using XGBoost ---- #
    print("Generating baseline scores from XGBoost...")
    baseline_score = xgb_model.predict_proba(X_rt)[:, 1]
    train_data["baseline_score"] = baseline_score

    # ---- Prepare training inputs ---- #
    user_embedding_dim = len(USER_EMBEDDINGS)

    train_inputs = {
        'user_embedding': train_data[USER_EMBEDDINGS].values.astype(np.float32),
        'real_time_features': X_rt.astype(np.float32),
        'baseline_score': train_data["baseline_score"].values.reshape(-1, 1).astype(np.float32)
    }

    train_labels = train_data["fraud_label"].values.astype(np.float32)

    print(f"User embedding dim: {user_embedding_dim}")
    print(f"Real-time feature dim: {real_time_dim}")
    print(f"Training samples: {len(train_labels)}")

    # ---- Build & compile model ---- #
    model = create_model(user_embedding_dim, real_time_dim)
    model.compile(
        optimizer=Adam(0.001),
        loss='binary_crossentropy',
        metrics=[tf.keras.metrics.AUC(name='pr_auc', curve='PR')]
    )

    # ---- Train model ---- #
    print("Training model...")
    history = model.fit(
        train_inputs,
        train_labels,
        validation_split=0.2,
        epochs=20,
        batch_size=1024,
        callbacks=[EarlyStopping(patience=3, restore_best_weights=True)],
        verbose=1
    )

    # ---- Save model ---- #
    output_path = os.path.join(args.model_dir, "wd_model")
    print(f"Saving model to: {output_path}")
    model.save(output_path)
    print("✅ Wide & Deep model training completed successfully!")
